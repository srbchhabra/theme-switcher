// TaskList.js

import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteTask, toggleTaskStatus } from '../redux/actions/taskActions';
import styles from "./tasklist.module.css"

function TaskList() {
  const taskslist = useSelector((state) => state?.tasks?.tasks); 
  const dispatch = useDispatch();

  const handleDeleteTask = (taskId) => {
    dispatch(deleteTask(taskId));
  };

  const handleToggleTaskStatus = (taskId) => {
    dispatch(toggleTaskStatus(taskId));
  };
  const currentTheme = useSelector((state) => state.theme.theme);
  const themeClass = currentTheme === 'light' ? styles.task : styles.taskDark;
  return (
    <div className="task-list">
      {taskslist?.map((task) => (
        <div key={task.id} className={`${styles.task} ${themeClass} ${task.completed ? 'completed' : ''}`}>
          <h3>{task.title}</h3>
          <p>{task.description}</p>
          <div className="task-actions">
            <button onClick={() => handleToggleTaskStatus(task.id)}>
              {task.completed ? 'Mark as Pending' : 'Mark as Completed'}
            </button>
            <button style={{marginLeft:'8px'}} onClick={() => handleDeleteTask(task.id)}>Delete</button>
          </div>
        </div>
      ))}
    </div>
  );
}

export default TaskList;
